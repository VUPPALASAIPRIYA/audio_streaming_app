package com.example.audiostreaming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AudiostreamingbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
